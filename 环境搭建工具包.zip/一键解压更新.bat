@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "RESEARCH_UNZIP_SELF=%~f0"
(
 powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { $text=[IO.File]::ReadAllText($env:RESEARCH_UNZIP_SELF,[Text.Encoding]::UTF8); $marker='# '+'POWERSHELL_START'; $pos=$text.IndexOf($marker); if($pos -lt 0){throw 'Script marker missing'}; & ([scriptblock]::Create($text.Substring($pos+$marker.Length))) } catch { Write-Host $_ -ForegroundColor Red; exit 1 }"
 if errorlevel 1 (
  echo 操作未全部完成，请查看上方错误。
  pause
  exit /b 1
 )
 echo.
 pause
 exit /b 0
)
# POWERSHELL_START
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath([IO.Path]::GetDirectoryName($env:RESEARCH_UNZIP_SELF))
Add-Type -AssemblyName System.IO.Compression.FileSystem
Write-Host '请输入ZIP所在文件夹，或ZIP文件的完整路径。'
Write-Host '直接回车：从Windows系统下载文件夹选取最新ZIP。'
$inputPath = (Read-Host '压缩包来源路径').Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($inputPath)) {
    $shell = New-Object -ComObject Shell.Application
    $downloadsFolder = $shell.NameSpace('shell:Downloads')
    if ($null -eq $downloadsFolder) { throw '无法读取Windows系统的下载文件夹。' }
    $sourcePath = $downloadsFolder.Self.Path
} else {
    $sourcePath = [Environment]::ExpandEnvironmentVariables($inputPath)
}
if (-not (Test-Path -LiteralPath $sourcePath)) { throw "来源路径不存在：$sourcePath" }
$sourceItem = Get-Item -LiteralPath $sourcePath -Force
if ($sourceItem.PSIsContainer) {
    $sourceDirectory = $sourceItem.FullName
    $latest = Get-ChildItem -LiteralPath $sourceDirectory -File -Filter '*.zip' |
        Sort-Object -Property @('LastWriteTime','CreationTime','Name') -Descending | Select-Object -First 1
    if ($null -eq $latest) { Write-Host "来源文件夹中没有ZIP压缩包：$sourceDirectory"; exit 0 }
} else {
    if (-not $sourceItem.Extension.Equals('.zip', [StringComparison]::OrdinalIgnoreCase)) { throw '指定文件不是ZIP压缩包。' }
    $latest = $sourceItem
    $sourceDirectory = $sourceItem.DirectoryName
}
$prefix = $root.TrimEnd('\') + '\'
$stageRoot = Join-Path ([IO.Path]::GetTempPath()) ('ResearchUpdate_' + [Guid]::NewGuid().ToString('N'))
$archive = $null
$checkedDirectories = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$clock = [Diagnostics.Stopwatch]::StartNew()
$progressState = @{ Last = -2.0 }
$phaseLabel = '打开压缩包'
$currentFile = $latest.FullName
$filesUpdated = $false
function Show-UpdateProgress([int]$phase, [int]$done, [int]$total, [string]$file, [switch]$Force) {
    if ($Force -or $done -eq $total -or ($done % 200) -eq 0 -or ($clock.Elapsed.TotalSeconds - $progressState.Last) -ge 2) {
        $progressState.Last = $clock.Elapsed.TotalSeconds
        Write-Host ('[{0}/3] {1}：{2}/{3}，已用 {4:N0} 秒' -f $phase,$phaseLabel,$done,$total,$clock.Elapsed.TotalSeconds)
        if ($file) { Write-Host ('  ' + $file) }
    }
}
function Assert-SafeDestination([string]$destination) {
    if (-not $destination.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "文件路径超出当前工具目录：$destination"
    }
    # Each destination file is checked; ancestor directories are checked once per phase.
    # .NET avoids tens of thousands of Test-Path/Get-Item command invocations.
    $current = $destination
    while ($current.Length -ge $root.Length) {
        $ancestor = -not $current.Equals($destination, [StringComparison]::OrdinalIgnoreCase)
        if ($ancestor -and $checkedDirectories.Contains($current)) { break }
        try {
            $attributes = [IO.File]::GetAttributes($current)
            if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "目标路径包含链接，请先检查：$current"
            }
        } catch [IO.FileNotFoundException] {
            # A new output file or directory is expected.
        } catch [IO.DirectoryNotFoundException] {
            # Still inspect its ancestors, including the existing destination root.
        }
        if ($ancestor) { [void]$checkedDirectories.Add($current) }
        if ($current.Equals($root, [StringComparison]::OrdinalIgnoreCase)) { break }
        $current = [IO.Path]::GetDirectoryName($current)
    }
}

try {
    Write-Host "来源目录：$sourceDirectory"
    Write-Host "最新ZIP：$($latest.Name)"
    Write-Host "更新位置：$root"
    Write-Host '覆盖同名文件，保留其他文件。下面会显示检查、解压和覆盖的进度。'
    $archive = [IO.Compression.ZipFile]::OpenRead($latest.FullName)
    $entries = New-Object 'System.Collections.Generic.List[object]'
    $destinations = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $phaseLabel = '检查压缩包路径'
    $checked = 0
    Show-UpdateProgress 1 0 $archive.Entries.Count '' -Force
    foreach ($entry in $archive.Entries) {
        $currentFile = $entry.FullName
        Show-UpdateProgress 1 $checked $archive.Entries.Count $currentFile
        $checked++
        $raw = $entry.FullName.Replace('/', '\')
        if ([string]::IsNullOrWhiteSpace($raw)) { continue }
        if ([IO.Path]::IsPathRooted($raw) -or $raw.Contains(':') -or ($raw.Split('\') -contains '..')) {
            throw "压缩包含有非法路径：$($entry.FullName)"
        }
        $relative = $raw
        # New packages contain the shared root. Strip it once, never nest it again.
        if ($relative.StartsWith('研究辅助工具\', [StringComparison]::OrdinalIgnoreCase)) {
            $relative = $relative.Substring('研究辅助工具\'.Length)
        }
        if ([string]::IsNullOrWhiteSpace($relative)) { continue }
        if (($relative.Split('\') -contains '研究辅助工具')) {
            throw "压缩包重复包含研究辅助工具层级：$($entry.FullName)"
        }
        foreach ($segment in $relative.TrimEnd('\').Split('\')) {
            if ([string]::IsNullOrWhiteSpace($segment) -or $segment -eq '.' -or
                $segment.EndsWith('.') -or $segment.EndsWith(' ') -or $segment.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or
                $segment -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\.|$)') {
                throw "压缩包含有Windows无效文件名：$($entry.FullName)"
            }
        }
        # Unix symlink entries are not regular files.
        if ((($entry.ExternalAttributes -shr 16) -band 61440) -eq 40960) { throw "不支持压缩包内的链接：$($entry.FullName)" }
        $destination = [IO.Path]::GetFullPath([IO.Path]::Combine($root, $relative))
        Assert-SafeDestination $destination
        if ($destination.Equals($latest.FullName, [StringComparison]::OrdinalIgnoreCase)) { throw '压缩包条目指向来源ZIP自身，已停止。' }
        $directory = $relative.EndsWith('\')
        if (-not $destinations.Add($destination.TrimEnd('\'))) { throw "压缩包存在重复目标路径：$($entry.FullName)" }
        $entries.Add([PSCustomObject]@{ Entry=$entry; Relative=$relative; Destination=$destination; Directory=$directory })
    }
    if ($entries.Count -eq 0) { throw '压缩包没有可解压的文件。' }
    Show-UpdateProgress 1 $checked $archive.Entries.Count '' -Force
    # Read all compressed data into a staging directory before overwriting files.
    [void][IO.Directory]::CreateDirectory($stageRoot)
    $phaseLabel = '解压到临时目录'
    $unpacked = 0
    Show-UpdateProgress 2 0 $entries.Count '' -Force
    foreach ($item in $entries) {
        $currentFile = $item.Relative
        Show-UpdateProgress 2 $unpacked $entries.Count $currentFile
        $unpacked++
        $stage = [IO.Path]::Combine($stageRoot, $item.Relative)
        if ($item.Directory) { [void][IO.Directory]::CreateDirectory($stage); continue }
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($stage))
        [IO.Compression.ZipFileExtensions]::ExtractToFile($item.Entry, $stage, $true)
    }
    Show-UpdateProgress 2 $unpacked $entries.Count '' -Force
    $archive.Dispose(); $archive = $null
    $written = 0
    $processed = 0
    $phaseLabel = '覆盖目标文件'
    $checkedDirectories.Clear()
    Show-UpdateProgress 3 0 $entries.Count '' -Force
    foreach ($item in $entries) {
        $currentFile = $item.Destination
        Show-UpdateProgress 3 $processed $entries.Count $currentFile
        $processed++
        Assert-SafeDestination $item.Destination
        if ($item.Directory) { [void][IO.Directory]::CreateDirectory($item.Destination); continue }
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($item.Destination))
        [IO.File]::Copy([IO.Path]::Combine($stageRoot, $item.Relative), $item.Destination, $true)
        $written++
    }
    Show-UpdateProgress 3 $processed $entries.Count '' -Force
    Write-Host "更新完成，写入 $written 个文件。" -ForegroundColor Green
    $filesUpdated = $true
    $phaseLabel = '将原ZIP放入回收站'
    $currentFile = $latest.FullName
    Write-Host '正在将本次ZIP放入Windows回收站……'
    # Explicitly request recycling; do not fall back to permanent deletion.
    Add-Type -AssemblyName Microsoft.VisualBasic
    [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile(
        $latest.FullName,
        [Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,
        [Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin,
        [Microsoft.VisualBasic.FileIO.UICancelOption]::ThrowException
    )
    Write-Host "原ZIP已放入回收站：$($latest.Name)" -ForegroundColor Green
} catch {
    $detail = $_.Exception.GetBaseException().Message
    $message = "阶段：$phaseLabel`r`n文件：$currentFile`r`n错误：$detail"
    if ($filesUpdated) {
        Write-Host '文件已更新，但原ZIP回收未完成，详情如下：' -ForegroundColor Yellow
    } else {
        Write-Host '更新失败，具体位置如下：' -ForegroundColor Red
    }
    Write-Host $message -ForegroundColor Red
    try {
        [IO.File]::WriteAllText((Join-Path $root '解压更新错误.log'), ([DateTime]::Now.ToString('s') + "`r`n" + $message), [Text.Encoding]::UTF8)
        Write-Host '错误详情已保存到BAT旁边的 解压更新错误.log。'
    } catch { }
    if ([IO.File]::Exists($latest.FullName)) { Write-Host '原ZIP仍在来源位置。' }
    if (-not $filesUpdated) { Write-Host '覆盖阶段失败时可能已有部分文件更新；修复错误后可重新运行。' }
    throw
} finally {
    if ($null -ne $archive) { $archive.Dispose() }
    if ([IO.Directory]::Exists($stageRoot)) { Remove-Item -LiteralPath $stageRoot -Recurse -Force -ErrorAction SilentlyContinue }
}
